# a Collection class

build with PHP 8.1
composer 2.2.5

To install the dependencies and get started just run 
```
composer install 
```

That's all.

