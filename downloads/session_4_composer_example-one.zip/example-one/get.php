<?php
require_once 'vendor/autoload.php';

//require_once 'vendor/guzzlehttp/guzzle/src/client.php';

use GuzzleHttp\Client;

$client = new Client();
$response = $client->request('GET', 'https://api.github.com/repos/guzzle/guzzle');

var_dump(json_decode($response->getBody(), true));